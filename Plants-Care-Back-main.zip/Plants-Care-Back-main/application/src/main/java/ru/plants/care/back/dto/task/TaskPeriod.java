package ru.plants.care.back.dto.task;

public enum TaskPeriod {
    HOURLY,
    DAILY,
    WEEKLY,
    MONTHLY,
    YEARLY
}
