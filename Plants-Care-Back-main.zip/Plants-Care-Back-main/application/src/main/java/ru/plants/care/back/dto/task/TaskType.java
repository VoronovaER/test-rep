package ru.plants.care.back.dto.task;

public enum TaskType {
    PLANT_WATERING,
    PLANT_FEEDING,
    PLANT_POLLING
}
