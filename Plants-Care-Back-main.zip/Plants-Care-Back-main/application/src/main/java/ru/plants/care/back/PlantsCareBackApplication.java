package ru.plants.care.back;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PlantsCareBackApplication {

    public static void main(String[] args) {
        SpringApplication.run(PlantsCareBackApplication.class, args);
    }

}
