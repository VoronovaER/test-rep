package ru.plants.care.back.dto.task;

public enum TaskRunStatus {
    WAITING,
    RUNNING,
    SUCCESS,
    FAILED
}
